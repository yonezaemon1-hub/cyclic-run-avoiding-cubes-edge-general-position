"""Public verifier runner: Python >=3.10 standard library only."""
from pathlib import Path
import hashlib, subprocess, sys
base=Path(__file__).resolve().parent
for folder,program in (("v01","verify.py"),("v02","verify_v02.py")):
    p=base/folder
    for line in (p/"SHA256SUMS.txt").read_text().splitlines():
        digest,name=line.split("  ",1)
        assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest, name
    run=subprocess.run([sys.executable,"-B","-I",program],cwd=p,capture_output=True,text=True,check=True)
    assert run.stdout.replace("\r\n","\n").strip()==(p/"EXPECTED_RESULTS.txt").read_text().strip(), folder
    print(f"PASS {folder}: source hashes and exact expected output")
