"""No.78 v0.2: exact finite bases, direct enumeration, and n=4 equality.
Standard library only. No floating point; no reliance on earlier proof scripts.
"""
from itertools import product, combinations
from collections import deque
from fractions import Fraction

I=((1,0,0),(0,1,0),(0,0,1))
T0=((1,0,0),(1,0,0),(1,0,0))
T1=((0,1,0),(0,0,1),(0,0,0))
def add(a,b): return tuple(tuple(x+y for x,y in zip(r,s)) for r,s in zip(a,b))
def mul(a,b): return tuple(tuple(sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)) for i in range(3))
def trace(a): return sum(a[i][i] for i in range(3))
T=add(T0,T1); powers=[I,T,mul(T,T)]; T3=mul(powers[2],T)
assert T3==add(add(powers[2],T),I)
print('PASS TRANSFER_RECURRENCE')
M={(b,g):mul(t,powers[g-1]) for b,t in enumerate((T0,T1)) for g in (1,2,3)}
def legal(x,n): return all(((x|(x<<n))>>i)&7!=7 for i in range(n))
minimum=Fraction(1); equal=0; cases=0; layouts=0
for gaps in product((1,2,3),repeat=4):
    n=sum(gaps); pos=(0,gaps[0],sum(gaps[:2]),sum(gaps[:3]))
    hist=[]
    for b in range(16):
        mat=I
        for j,g in enumerate(gaps):mat=mul(mat,M[(b>>j&1,g)])
        hist.append(trace(mat))
    # Independent count by full enumeration, no matrix used.
    direct=[0]*16
    for x in range(1<<n):
        if legal(x,n):direct[sum((x>>p&1)<<j for j,p in enumerate(pos))]+=1
    assert hist==direct
    C=sum(hist); assert C>0
    for c in range(16):
        E=sum(hist[b] for b in range(16) if (b^c).bit_count()==2)
        assert 11*E>=3*C,(gaps,c,E,C)
        equal+=11*E==3*C; minimum=min(minimum,Fraction(E,C)); cases+=1
    layouts+=1
assert minimum==Fraction(3,11)
print('PASS EXACT_BASES',layouts,cases,'MIN',minimum,'EQUALITY_CASES',equal)
print('PASS DIRECT_PROJECTION_HISTOGRAMS',layouts)
assert Fraction(8,11)<Fraction(19,25)
# n=4: independent direct geodesic enumeration using actual graph distances.
n=4; V=[x for x in range(1<<n) if legal(x,n)]; E=[(x,x|1<<j,j) for x in V for j in range(n) if not x>>j&1 and legal(x|1<<j,n)]
adj={x:[] for x in V}
for idx,(x,y,j) in enumerate(E):adj[x].append((y,idx));adj[y].append((x,idx))
bad=set()
for s in V:
    dist={s:0};q=deque([s])
    while q:
        x=q.popleft()
        for y,_ in adj[x]:
            if y not in dist:dist[y]=dist[x]+1;q.append(y)
    def visit(v,path):
        for comb in combinations(path,3):bad.add(sum(1<<i for i in comb))
        for w,e in adj[v]:
            if dist[w]==dist[v]+1:visit(w,path+[e])
    visit(s,[])
classes=[sum(1<<i for i,e in enumerate(E) if e[2]==j) for j in range(n)]
expected={a|b for a,b in combinations(classes,2)}
actual=set()
for comb in combinations(range(len(E)),8):
    mask=sum(1<<j for j in comb)
    if all(mask&b!=b for b in bad):actual.add(mask)
assert len(V)==11 and len(E)==16 and actual==expected and len(actual)==6
# If size >=9 existed, all its 8-subsets would be in actual; test separately.
for comb in combinations(range(len(E)),9):
    mask=sum(1<<j for j in comb)
    assert any(mask&b==b for b in bad)
print('PASS N4_GEODESIC_EXHAUSTION',len(V),len(E),'FORBIDDEN_TRIPLES',len(bad),'MAX',8,'MAX_SETS',len(actual))
print('FINAL: PASS V02 FINITE BASES AND N4 EQUALITY')
