# Exact edge general position in cyclic run-avoiding cubes for every k >= 3

No.78 v0.2 — PRIVATE HOLD — 2026-11-19 JST
Author-side computer-assisted proof candidate. Independent AI audit and Windows reproduction pending. NOVELTY INCONCLUSIVE / REFERENCES PARTIAL. Not peer reviewed. All rights reserved.

## Scope and relationship to frozen v0.1

This supplement extends the theorem of the byte-frozen v0.1 manuscript (in FROZEN_V01.zip) from k>=4 to every integer n>=k>=3. The parent contains the independent elementary star and projection lemmas, the count and density recurrences, and the analytic k>=4 proof. No result from No.75–77 is assumed. The new k=3 upper bound uses an exact finite transfer-matrix certificate and an analytic induction in the gaps, not enumeration of all large graphs.

Let H(n,k) be the induced graph of the n-cube on binary words with no cyclic block of k ones; let C_n^(k) denote its order and A_m^(k) the linear run-avoiding word count, with A_0=1. Edge general position means that no geodesic contains three distinct selected edges. Set B_n=2(C_n^(k)-A_(n-1)^(k)).

**Theorem (candidate).** For every n>=k>=3, gp_e(H(n,k))=B_n, and its maximum sets are exactly the unions of two distinct complete coordinate edge classes.

The lower bound and equality classification within sets using at most two directions follow from v0.1 §1. The full case k>=4 is v0.1 §§2–5, unchanged. It remains to prove k=3, including the equality case n=4.

## 1. Four-coordinate exclusion lemma for cyclic triple avoidance

Let n>=4, let four distinct marked coordinates be given in cyclic order, and let c be ANY four-bit pattern (no feasibility restriction is imposed). Let E denote the number of legal cyclic words differing from c at exactly two of the marked coordinates, and let C denote the total number of legal words. Then

    11 E >= 3 C.

Proof. Let the positive integer gaps g_1,...,g_4 be the cyclic distances between successive marked coordinates, summing to n. A rotation lets the first marked coordinate be 0. The state r=0,1,2 counts the trailing ones. With rows denoting source states and columns denoting destination states, write

    T_0 = [[1,0,0],[1,0,0],[1,0,0]],
    T_1 = [[0,1,0],[0,0,1],[0,0,0]],
    T = T_0+T_1.

For a prescribed marked bit pattern b, the number of legal completions is

    N_g(b) = tr( T_(b_1) T^(g_1-1) ... T_(b_4) T^(g_4-1) ).

Indeed each closed state walk gives a cyclic word with no triple ones. Every legal word has at least one zero, which forces state 0 immediately after it and determines all states uniquely; conversely the all-one word cannot give a closed walk. This proves the trace identity, with fixed labeled positions and no division by rotations. Thus C=sum_b N_g(b) and E=sum_(d_H(b,c)=2) N_g(b).

Direct matrix multiplication gives T^3=T^2+T+I. For any g_i>=4, the value L(g,c)=11E-3C is the sum of its three values with g_i replaced by g_i-1,g_i-2,g_i-3 and all other gaps and c unchanged. This follows by linearity in the corresponding power of T, without any positivity assumption on the coefficients in L. All new gaps remain positive, so lowering a gap also leaves a valid four-mark cyclic instance. Induction on the total gap sum reduces L>=0 to g in {1,2,3}^4 and all c in {0,1}^4. This inclusion of ALL c is essential: no assumption about preserving feasibility under gap reduction is made.

The finite certificate verify_v02.py verifies 81 gap tuples times 16 center patterns = 1,296 inequalities by exact integer matrix multiplication. It independently counts each projection histogram by directly enumerating all words of the corresponding length (4 through 12). Both methods agree on every histogram. Minimum E/C is 3/11 and there are eight base equality cases. This completes the computer-assisted induction. The lower bound 3/11 is sharp as a universal four-coordinate inequality (for example n=4, center pattern of weight one).

## 2. Upper bound for k=3, n>=5

Suppose S uses at least three directions. By the elementary star lemma proved in v0.1 §1, it is a star forest. If its largest star degree d<=3, then |S| <= 3C/4 < 19C/25 <= B_n, using the density recurrence proved in v0.1 §2.

If d>=4, choose any four arms of a star at vertex z. Let c be its projected pattern on these four coordinates. Every legal vertex x counted by E in §1 has two agreements and two disagreements with z on these coordinates. For any incident selected edge direction l, remove l from the four marked coordinates if it is present. At least one agreement i and one disagreement j remain. These are two different arms of the star, distinct from l. The projection of the incident edge onto i,j is a leaf of the two-arm star. The projection lemma of v0.1 §1 forbids that edge. Thus all E vertices are excluded from incidence with S. Since a star forest has no more edges than its incident vertices, |S| <= C-E <= 8C/11 < 19C/25 <= B_n. Both degree cases are strict. This proves the value and classification for all n>=5, k=3.

## 3. Small cases and equality

For n=3, k=3: C=7, B=6, and any S using at least three directions has |S|<=3C/4<6. For n=4, k=3: C=11, B=8. The degree bound gives |S|<= floor(4C/5)=8, irrespective of star degree for sets using at least three directions. To settle uniqueness of the coordinate-pair form even here, verify_v02.py separately builds the actual 11-vertex, 16-edge graph, computes BFS distances from every vertex, and enumerates every geodesic by moving along edges of increasing source distance. It generates 96 forbidden edge triples, tests all binomial(16,8)=12,870 eight-edge subsets and all binomial(16,9)=11,440 nine-edge subsets. Exactly six eight-edge sets survive, precisely the unions of two complete coordinate classes; no nine-edge set survives. Any larger set would have a nine-edge subset, so this also independently confirms the value 8.

This completes the stated candidate theorem within n>=k>=3. No n<k convention is asserted. No k=2 result is assumed or claimed by this supplement.

## Verification and limitations

Parent v0.1 manifest, finite verifier, and expected stdout checked afresh from the frozen ZIP. The new exact verifier uses Python 3.10+ standard library, no numerical solvers. Its finite checks are part of the k=3 proof and do not independently establish the analytic lemmas. Independent mathematical audit of the complete parent and supplement is still required. The source search is inherited as preliminary only; no additional priority claim is made in this revision. See parent references. Do not publish.
