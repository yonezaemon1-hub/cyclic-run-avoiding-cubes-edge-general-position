# Exact edge general position numbers of cyclic run-avoiding cubes for k >= 4

No.78 v0.1 — PRIVATE HOLD — 2026-11-19 JST
Author-side analytic proof candidate. Independent AI audit and Windows reproduction pending. NOVELTY INCONCLUSIVE / REFERENCES PARTIAL. Not peer reviewed. All rights reserved.

## Model and results
For integers n>=k>=3, let H(n,k) be the induced subgraph of the binary n-cube on words containing no cyclic block of k ones. Write C_n=C_n^(k) for its order, and A_m=A_m^(k) for the number of linear length-m words avoiding k consecutive ones (A_0=1). A selected edge set S is in edge general position if no three distinct selected edges lie on a common geodesic. Let B_n=2(C_n-A_(n-1)).

Theorem: For all n>=k>=4, gp_e(H(n,k))=B_n. The maximum sets are exactly the unions of any two distinct complete coordinate edge classes.

Partial result for k=3: gp_e=B_n at n=3,4. For n>=5, any S larger than B_n must use at least three coordinates and have largest star degree between 4 and 11 inclusive. No claim of equality for all k=3 is made.

No.75–77 main theorems are not assumed. The elementary projection and star lemmas used in No.77 are reproduced below. The proof of the theorem is analytic; finite checks are corroboration only.

## 1. Geometry and lower bound
The legal family is downward closed. A path via x AND y between any legal x,y attains Hamming distance, so H(n,k) is isometric in Q_n. A geodesic never repeats a coordinate. Each coordinate class has C_n-A_(n-1) edges: a legal word with a one there corresponds to its downward edge, and words with a zero there are exactly linear legal words of length n-1. Rotation gives the same count in every direction. Any union of two classes is in edge general position, of size B_n. A set using at most two coordinates cannot exceed B_n; equality requires two complete classes.

Projection lemma: If S contains two edges of a star at c, in coordinates i,j, then a selected edge in another coordinate l cannot project on i,j to a leaf of that two-arm star. Indeed let z be the corresponding leaf and w the endpoint of the edge with w_l=z_l. These vertices agree on i,j,l. Concatenate the other leaf -> c -> z, a geodesic from z to w, and the selected edge. The directions of these parts are disjoint, so this is a geodesic containing three selected edges, a contradiction.

Star lemma: If S uses at least three directions, the graph of its selected edges is a star forest. A simple three-edge path must repeat a direction, else it is a geodesic. Its directions must then be i,j,i. The two consecutive two-arm stars have leaf projections on i,j covering all four patterns, so the projection lemma forbids a third direction anywhere. Thus no simple three-edge path exists. The selected graph is bipartite, hence its nontrivial components are stars. If the maximum degree is d and E vertices are excluded from incidence with S, then |S|<=d/(d+1)(C_n-E).

## 2. Counting and density
The linear counts satisfy A_m=2^m for 0<=m<k and A_m=sum_{j=1}^k A_(m-j) for m>=k. The cyclic counts satisfy C_j=2^j-1 for 1<=j<=k under the periodic-word convention at j<k, and C_n=sum_{j=1}^k C_(n-j) for n>k. To see this, take the k-state matrix T of transitions of the run of ones: every state r=0..k-1 can move to state 0 by emitting zero, and r<k-1 can move to r+1 by emitting one. Legal cyclic words correspond bijectively to closed walks with a fixed starting index, since at least one zero determines all run states uniquely. Thus C_j=tr(T^j) for positive j. The characteristic polynomial is x^k-x^(k-1)-...-1 (companion matrix, up to transposition/convention), and Cayley-Hamilton gives the recurrence for n>k. Consequently any fixed linear combination of C_n and A_(n-1) satisfies this recurrence for n>=k+1, and a nonnegative (or positive) block of k consecutive values propagates forward.

For k>=5, B_n/C_n>10/11 for n>=k. This is equivalent to 6C_n-11A_(n-1)>0. At n=k this difference is 2^(k-1)-6>0. For n=k+t with 1<=t<=k-1, two disjoint starts of maximal runs of length at least k in a non-all-one cyclic word are impossible (would require at least 2k+2 positions). A bad non-all-one cyclic word has a unique occurrence of 0 followed by k ones. Hence C_n=2^n-1-n*2^(n-k-1). For linear length m=n-1, an illegal word similarly has exactly one maximal long-run start, either at the first position or preceded by zero. Thus A_(n-1)=2^(n-1)-(t+1)*2^(t-2). Substitution gives
6C_n-11A_(n-1)=2^(t-2)(2^(k+1)-12k-t+11)-6.
For t=1 the expression in parentheses is at least 14 (at k=5, increasing in k), hence the difference is at least 1. For 2<=t<=k-1 it is at least 2^(k+1)-13k+12>=11 (increasing for k>=5), hence the difference is >=5. The k positive bases n=k..2k-1 propagate by recurrence.

For k=4, B_n/C_n>=11/13 for n>=4: verify n=4,5,6,7 by C=(15,26,51,99), A_(n-1)=(8,15,29,56), and propagate 13B_n-11C_n. In addition B_n/C_n>6/7 for n>=6: verify n=6,7,8,9, yielding C=(51,99,191,367), A_(n-1)=(29,56,108,208), hence 7B_n-6C_n=(2,8,16,24), all positive. (At n=9: 7*318-6*367=24.) Propagate this block of four values.

For k=3, B_n/C_n>=19/25 for n>=5: the three bases n=5,6,7 have C=(21,39,71), A_(n-1)=(13,24,44), B=(16,30,54). The differences 25B-19C are (1,9,1), and the recurrence propagates them.

## 3. Uniform vertex exclusion
Suppose a star at c has d arms. Choose m pairwise nonadjacent cyclic coordinates among the arms. The induced graph of these coordinates in the cycle is a union of paths if proper, or a cycle if full. Thus at least floor(d/2) independent coordinates exist; for d odd and the coordinate set proper this improves to ceil(d/2).

Let X be a uniform legal vertex. Conditional on specified bits at any subset of the chosen coordinates, the probability of either value at any other chosen coordinate is between 1/5 and 4/5. Deleting a one injects the conditioned one class into the zero class. Turning a zero to one and clearing both cyclic neighbors gives a legal word (the new one is isolated; downward closure handles the other positions) and preserves the condition. It has at most four preimages, since only the two former neighbor bits are unknown. Thus the zero class is at most four times the one class. The same bounds apply to agreement or disagreement with the fixed center c.

Let Y be the number of disagreements on these m coordinates. The event 2<=Y<=m-2 excludes the vertex from every selected edge: after ignoring its incident edge direction, at least one agreeing and one disagreeing star coordinate remain. Their two-bit projection is a leaf of a two-arm star, forbidden by the projection lemma.

A uniform lower bound p_m on this event holds even for adaptive conditional distributions. Set f_m(s)=1 for 2<=s<=m-2 and 0 otherwise. For j=m-1,...,0 set f_j(s)=min{(4 f_(j+1)(s)+f_(j+1)(s+1))/5,(f_(j+1)(s)+4 f_(j+1)(s+1))/5}. Backward induction using the conditional probability interval proves the bound p_m=f_0(0). Exact arithmetic gives p_4=9/125, p_5=97/625, p_6=757/3125. In particular |S| <= d/(d+1)(1-p_m) C_n, and also |S| <= (1-p_m) C_n.

## 4. Upper bound for k>=5
Assume three or more selected directions. Then S is a star forest. If d<=10, |S|<=10 C_n/11<B_n. If d>=11, at least five independent coordinates exist, so |S|<=(528/625)C_n <10 C_n/11<B_n. This gives strict inequality for all sets using three or more directions.

## 5. Upper bound for k=4
Again assume three or more directions. When d<=5, |S|<=5 C_n/6<11 C_n/13<=B_n. If d=6 then n>=6, where B_n/C_n>6/7, giving strict inequality. If 7<=d<=9 and n>=8, there exist four pairwise nonadjacent arm coordinates (in particular for d=7 it is a proper subset of the cycle). Hence |S|<= (9/10)(116/125) C_n = (522/625) C_n < (11/13) C_n <= B_n. If d>=10, use five independent arms and |S|<= (528/625) C_n < (11/13) C_n <=B_n.

The sole missing case is n=d=7. All seven directions are arms of a star. Its center c is legal and has Hamming weight at most five, since six ones on a 7-cycle contain a run of six. If weight(c)>=2, the all-zero word has at least two agreements and two disagreements with c. If weight(c)<=1, select two zero positions of c and set just those two positions to one, and all other positions to zero; this word is legal for k=4 and has between two and three disagreements and at least four agreements. The projection lemma excludes the resulting vertex. Thus |S|<=7*98/8=85.75 < B_7=86. This handles all cases, including equality, and proves the theorem.

## 6. Partial result for k=3
At n=3 all sets using three directions satisfy |S|<=3*7/4<6=B_3. At n=4 the degree bound yields |S|<=floor(4*11/5)=8=B_4. At n>=5, d<=3 gives |S|<=3/4 C_n <19/25 C_n<=B_n. For d>=12 choose six independent arms, yielding |S|<=2368/3125 C_n<19/25 C_n<=B_n. The remaining d=4..11 are not resolved by these inequalities. No uniqueness claim at n=4.

## References and scope
Klavzar and Tan, Edge General Position Sets in Fibonacci and Lucas Cubes, Bull. Malays. Math. Sci. Soc. 46 (2023), DOI 10.1007/s40840-023-01517-y. Ordinary k=2 problem and standard two-class construction. That construction is not claimed new.
Mollard, The (non-)existence of perfect codes in Lucas cubes, arXiv:2004.10198: generalized Lucas cube context, different parameter (perfect codes).
The literature search was preliminary; other uses of k-Lucas cube or generalized Lucas cube can describe different models. Full citation review and priority assessment pending. No world-first claim. No public release authorized.
