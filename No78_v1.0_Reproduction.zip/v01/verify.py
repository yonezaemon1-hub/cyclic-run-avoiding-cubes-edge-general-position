"""Independent finite corroboration of No.78, not a proof of the universal theorem."""
from fractions import Fraction as F
from itertools import combinations, product

def words(n,k,cyclic):
    for x in range(1<<n):
        y=x|(x<<n) if cyclic else x
        if all(((y>>i)&((1<<k)-1)) != (1<<k)-1 for i in range(n if cyclic else max(0,n-k+1))):
            yield x

def counts(k,N):
    A=[1]; C=[None]+[2**j-1 for j in range(1,k+1)]
    for j in range(1,N+1):
        A.append(2**j if j<k else sum(A[-k:]))
        if j>k:C.append(sum(C[-k:]))
    return A,C

# Separate enumeration from recurrence; check all coordinate counts and density.
cases=coords=0
for k in range(3,11):
    A,C=counts(k,15)
    for n in range(k,16):
        V=list(words(n,k,True)); B=2*(C[n]-A[n-1])
        assert len(V)==C[n] and len(list(words(n-1,k,False)))==A[n-1]
        for i in range(n):
            assert sum((x>>i)&1 for x in V)*2==B
            coords+=1
        if k>=5: assert 11*B>10*C[n]
        if k==4:
            assert 13*B>=11*C[n]
            if n>=6: assert 7*B>6*C[n]
        if k==3 and n>=5: assert 25*B>=19*C[n]
        cases+=1
print('PASS DIRECT_COUNTS',cases,'COORDINATES',coords)

# Check initial-block formula for a broad range, using integers after scaling by 2.
cases=0
for k in range(5,101):
    A,C=counts(k,2*k-1)
    assert 6*C[k]-11*A[k-1]==2**(k-1)-6>0
    for t in range(1,k):
        n=k+t
        assert C[n]==2**n-1-n*2**(t-1)
        assert 2*A[n-1]==2**n-(t+1)*2**(t-1)
        assert 2*(6*C[n]-11*A[n-1])==2**(t-1)*(2**(k+1)-12*k-t+11)-12>0
        cases+=1
print('PASS INITIAL_BLOCK_FORMULA',cases)

# Enumerate all deterministic extremal policies on the count state by forward DP
# for a second derivation of the lower bound: at each level optimize all state choices
# backwards using exact integers with denominator 5^remaining.
for m,expected in [(4,F(9,125)),(5,F(97,625)),(6,F(757,3125))]:
    vals=[int(2<=s<=m-2) for s in range(m+1)]
    for j in range(m,0,-1):
        vals=[min(4*a+b,a+4*b) for a,b in zip(vals,vals[1:])]
    assert F(vals[0],5**m)==expected
    print('PASS ADAPTIVE_PROBABILITY',m,str(expected))
assert F(528,625)<F(11,13)<F(10,11)
assert F(9,10)*F(116,125)<F(11,13)
assert F(2368,3125)<F(19,25)
print('PASS RATIONAL_INEQUALITIES')

# Direct finite check of the special n=d=7 case, independent of the construction.
V=set(words(7,4,True)); full=[c for c in V if all(c^(1<<i) in V for i in range(7))]
for c in full:
    excluded=[x for x in V if 2<=(x^c).bit_count()<=5]
    assert excluded
assert F(7,8)*(len(V)-1)<2*(len(V)-len(list(words(6,4,False))))
print('PASS N7_FULL_STAR',len(full))

# Exhaustively verify the conditional-probability lemma for independent coordinate
# sets of sizes up to four in small cyclic graphs; no recurrence used here.
cases=0
for k in range(3,7):
    for n in range(k,11):
        V=list(words(n,k,True))
        for q in range(1,min(4,n//2)+1):
            for I in combinations(range(n),q):
                if any((a-b)%n in (1,n-1) for a,b in combinations(I,2)):continue
                # Projection histogram; condition on q-1 specified entries.
                hist=[0]*(1<<q)
                for x in V:hist[sum(((x>>i)&1)<<j for j,i in enumerate(I))]+=1
                for j in range(q):
                    for mask in range(1<<q):
                        if (mask>>j)&1:continue
                        z,o=hist[mask],hist[mask|(1<<j)]
                        assert o<=z<=4*o
                        cases+=1
print('PASS CONDITIONAL_COUNTS',cases)
print('FINAL: PASS FINITE_CORROBORATION_ONLY')
