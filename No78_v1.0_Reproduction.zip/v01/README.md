No.78 v0.1 | PRIVATE HOLD

Analytic candidate theorem for cyclic run-avoiding cubes, n>=k>=4, and partial results for k=3. Read MANUSCRIPT.md first. Independent audit, Windows reproduction and full prior-art review remain outstanding. All rights reserved.

Python 3.10+, standard library only:
  python -B -I verify.py
Compare stdout with EXPECTED_RESULTS.txt (normalizing line endings only). SHA256SUMS.txt lists all other files. Finite corroboration is not a proof of the infinite theorem. No older research package is required.
